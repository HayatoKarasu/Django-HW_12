from django.db import models
from django.urls import reverse_lazy


class Human(models.Model):
    fio = models.CharField(max_length=150, verbose_name='ФИО')
    character = models.TextField(blank=True, verbose_name='Характеристика')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата_создания')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='Дата_обновления')
    photo = models.ImageField(upload_to='media/%Y/%m/%d', verbose_name='Фото')
    is_published = models.BooleanField(default=True, verbose_name='Регистрация')
    profession = models.ForeignKey('Prof', on_delete=models.PROTECT, null=True, verbose_name='Профессия')

    def get_absolute_url(self):
        return reverse_lazy('View_human', kwargs={'pk': self.pk})

    class Meta:
        verbose_name = 'Человек'
        verbose_name_plural = 'Люди'
        ordering = ['-created_at']


class Prof(models.Model):
    title = models.CharField(max_length=150, db_index=True, verbose_name='Профессия')

    def get_absolute_url(self):
        return reverse_lazy('Prof', kwargs={'profession_id': self.pk})

    class Meta:
        verbose_name = 'Профессия'
        verbose_name_plural = 'Профессии'
        ordering = ['title']
