from django.contrib import admin
from .models import Human, Prof


class HumansAdmin(admin.ModelAdmin):
    list_display = ('id', 'profession', 'fio', 'character', 'created_at', 'updated_at', 'photo', 'is_published')
    list_display_links = ('id', 'fio')
    search_fields = ('fio', 'character')
    list_filter = ('id', 'is_published')
    list_editable = ['profession', 'is_published']


class ProfAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')
    list_display_links = ('id', 'title')


admin.site.register(Human, HumansAdmin)
admin.site.register(Prof, ProfAdmin)
